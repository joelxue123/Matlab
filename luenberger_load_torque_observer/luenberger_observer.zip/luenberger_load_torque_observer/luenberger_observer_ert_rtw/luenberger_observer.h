/*
 * File: luenberger_observer.h
 *
 * Code generated for Simulink model 'luenberger_observer'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Tue Jul  2 18:43:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_luenberger_observer_h_
#define RTW_HEADER_luenberger_observer_h_
#ifndef luenberger_observer_COMMON_INCLUDES_
#define luenberger_observer_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                /* luenberger_observer_COMMON_INCLUDES_ */

#include "luenberger_observer_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Real-time Model Data Structure */
struct tag_RTM_luenberger_observer_T {
  const char_T * volatile errorStatus;
};

/* Model entry point functions */
extern void luenberger_observer_initialize(void);
extern void luenberger_observer_step(void);
extern void luenberger_observer_terminate(void);

/* Real-time Model object */
extern RT_MODEL_luenberger_observer_T *const luenberger_observer_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/Constant' : Unused code path elimination
 * Block '<Root>/Gain' : Unused code path elimination
 * Block '<Root>/Gain1' : Unused code path elimination
 * Block '<Root>/Integrator' : Unused code path elimination
 * Block '<Root>/Pulse Generator' : Unused code path elimination
 * Block '<Root>/Scope' : Unused code path elimination
 * Block '<S1>/Gain2' : Unused code path elimination
 * Block '<S1>/Gain3' : Unused code path elimination
 * Block '<S1>/Gain4' : Unused code path elimination
 * Block '<S1>/Gain5' : Unused code path elimination
 * Block '<S1>/Gain6' : Unused code path elimination
 * Block '<S1>/Integrator1' : Unused code path elimination
 * Block '<S1>/Integrator2' : Unused code path elimination
 * Block '<S1>/Sum1' : Unused code path elimination
 * Block '<S1>/Sum2' : Unused code path elimination
 * Block '<Root>/Sum' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'luenberger_observer'
 * '<S1>'   : 'luenberger_observer/Subsystem'
 */
#endif                                 /* RTW_HEADER_luenberger_observer_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
