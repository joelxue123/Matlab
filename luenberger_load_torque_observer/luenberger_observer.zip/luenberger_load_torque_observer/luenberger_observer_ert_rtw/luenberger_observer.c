/*
 * File: luenberger_observer.c
 *
 * Code generated for Simulink model 'luenberger_observer'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Tue Jul  2 18:43:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "luenberger_observer.h"

/* Real-time model */
static RT_MODEL_luenberger_observer_T luenberger_observer_M_;
RT_MODEL_luenberger_observer_T *const luenberger_observer_M =
  &luenberger_observer_M_;

/* Model step function */
void luenberger_observer_step(void)
{
  /* (no output/update code required) */
}

/* Model initialize function */
void luenberger_observer_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(luenberger_observer_M, (NULL));
}

/* Model terminate function */
void luenberger_observer_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
